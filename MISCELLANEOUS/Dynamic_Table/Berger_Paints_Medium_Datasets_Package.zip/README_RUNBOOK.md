Berger Paints Medium Dataset Package
Generated: 2025-11-09T19:13:40.501820

Contains medium-sized CSV datasets for pipeline testing (~tens of MBs total).
Files in /csvs/

Runbook:
1. Upload desired CSV files to internal stages using snowsql PUT.
2. Run SQL to create schemas/tables/streams/procedures.
3. Call orchestrator or resume the scheduled task.
