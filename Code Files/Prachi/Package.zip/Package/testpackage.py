from MyPackage import *

print(say_hello("prachi"))
print(add(4,7))